import SwiftUI
import RealityKit
struct ContentView: View {
    @State var Browse: Bool = false
    var body: some View {
        ZStack {
            ARViewContainer().edgesIgnoringSafeArea(.all)
            ControlView(Browse: $Browse)
        }
    }
}
struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        return arView
    }
    func updateUIView(_ uiView: ARView, context: Context) {
        // 执行额外的内容
    }
}

