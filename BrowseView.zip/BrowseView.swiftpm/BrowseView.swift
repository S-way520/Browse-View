import SwiftUI
struct BrowseView: View {
    @Binding var Browse: Bool
    @State var selectedRect = false
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                ModelsByCategoryGrid(Browse: $Browse)
            }
            .navigationTitle("八年级 上册")
            .navigationBarItems(leading: Menu {
                Picker(selection: $selectedRect, label: Text("Sorting options")) {
                    Text("初中 八年级 上册 人教版").tag(0)
                    Text("初中 八年级 下册 人教版").tag(1)
                    Text("初中 九年级 全一册 人教版").tag(2)
                    Text("高中 必修一 人教版").tag(3)
                    Text("高中 必修二 人教版").tag(4)
                    Text("高中 必修三 人教版").tag(5)
                    Text("高中 选择性必修一 人教版").tag(6)
                    Text("高中 选择性必修二 人教版").tag(7)
                    Text("高中 选择性必修三 人教版").tag(8)
                }
            }label: {
                HStack {
                    Image(systemName: "books.vertical")
                    Text("书籍")
                }
            })
            .navigationBarItems(trailing: Button(action: {
                self.Browse.toggle()
            }, label: {
                Text("完成")
            }))
        }
    }
}

struct ModelsByCategoryGrid: View {
    @Binding var Browse: Bool
    let models = Models()
    var body: some View {
        VStack {
            ForEach(ModelCategory.allCases, id: \.self) { category in
              //  if let modelsByCategory = models.get(category: category) {
                HGrid(Browse: $Browse, title: category.label, items: models.get(category: category))
              //  }
            }
        }
    }
}

struct HGrid: View {
    @Binding var Browse: Bool
    var title: String
    var items: [Model]
    private let gridItemLayout = [GridItem(.fixed(150))]
    var body: some View {
        VStack(alignment: .leading) {
            Separater()
            Text(title)
                .font(.title2).bold()
                .padding(.leading, 20)
                .padding(.top, 20)
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHGrid(rows: gridItemLayout, spacing: 30) {
                    ForEach(0..<items.count, id: \.self) {index in
                        let model = items[index]
                        ItemButton(model: model) {
                            print("预览: 选择\(model.name)放置")
                            self.Browse = false
                        }
                    }
                }
                .padding(.horizontal, 20)
            }
        }
    }
}
struct ItemButton: View {
    let model: Model
    let action: () -> Void
    var body: some View {
        Button(action: {
            self.action()
        }){
            Image(uiImage: self.model.thumbnail)
                .resizable()
                .frame(height: 150)
                .aspectRatio(1/1, contentMode: .fit)
                .background(Color(UIColor.secondarySystemFill))
                .cornerRadius(8.0, antialiased: true)
        }
    }
}
struct Separater: View {
    var body: some View {
        Divider()
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
    }
}
