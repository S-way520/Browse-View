import SwiftUI
import RealityKit
import Combine

enum ModelCategory: CaseIterable {
    case table
    case chair
    case decor
    case light
    var label: String {
        get {
            switch self {
            case .table:
                return "第一章 机械运动"
            case .chair:
                return "第二章 声现象"
            case .decor:
                return "第三章 物态变化"
            case .light:
                return "第四章 光现象"
            }
        }
    }
}

class Model {
    var name: String
    var category: ModelCategory
    var thumbnail: UIImage
    var modelEntity: ModelEntity?
    var scaleCompensation: Float
    
    init(name: String, category: ModelCategory, scaleCompensation: Float = 1.0) {
        self.name = name
        self.category = category
        self.thumbnail = UIImage(named: name) ?? UIImage(systemName: "photo")!
        self.scaleCompensation = scaleCompensation
    }
    
}

struct Models {
    var all: [Model] = []
    init(){
        //Table
        let dinigTable = Model(name: "dining_table", category: .table, scaleCompensation: 0.32/100)
        let familyTable = Model(name: "family_table", category: .table, scaleCompensation: 0.32/100)
        self.all += [dinigTable, familyTable]
        //Chairs
        let diningChair = Model(name: "dining_Chair", category: .chair, scaleCompensation: 0.32/100)
        let eamesChairWhite = Model(name: "eames_chair_white", category: .chair, scaleCompensation: 0.32/100)
        let eamesChairWoodgrain = Model(name: "eames_chair_woodgrain", category: .chair, scaleCompensation: 0.32/100)
        self.all += [diningChair, eamesChairWhite, eamesChairWoodgrain]
        //Decor
        let cupSaucerSet = Model(name: "cup_saucer_set", category: .decor, scaleCompensation: 0.32/100)
        self.all += [cupSaucerSet]
        //Lights
        let floorLampClassic = Model(name: "floor_lamp_classic", category: .light, scaleCompensation: 0.32/100)
        self.all += [floorLampClassic]
    }
    func get(category: ModelCategory) -> [Model] {
        return all.filter({$0.category == category})
    }
}
