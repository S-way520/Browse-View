import SwiftUI
struct ControlView: View {
    @State var Hide = false
    @Binding var Browse: Bool
    var body: some View {
        VStack {
            Spacer()
            ZStack {
                BottomBar(Browse: $Browse)
                    .offset(y: Hide ? 120 : 0)
                    .animation(.easeInOut(duration: 0.5), value: Hide)
                HideBar(Hide: $Hide)
                    .offset(x: -130, y: -5)
            }
        }
        
    }
}
struct HideBar: View {
    @Binding var Hide: Bool
    var body: some View {
        HStack {
            ZStack {
                Button(action: {
                    self.Hide.toggle()
                }, label: {
                    Image(systemName: "greaterthan.circle")
                        .rotationEffect(Angle(degrees: Hide ? 90 : 0))
                        .font(.title)
                        .background(Color.black.opacity(0.8))
                        .cornerRadius(12, antialiased: true)
                        .padding(10)
                })
                
            }
            
        }
    }
}
struct BottomBar: View {
    @Binding var Browse: Bool
    var body: some View {
        HStack {
            //最近放置
            BoButton(name: "clock") {
                print("one Tab")
            }
            Spacer()
                .frame(width: 40)
            //预览
            BoButton(name: "rectangle.grid.3x2") {
                self.Browse.toggle()
            }.sheet(isPresented: $Browse) {
                BrowseView(Browse: $Browse)
                    //.presentationDetents([.medium, .large])
            }
            Spacer()
                .frame(width: 40)
            //设置
            BoButton(name: "gear") {
                print("there Tab")
            }
        }
        .frame(maxHeight: 40)
        .padding(.horizontal, 10)
        .padding(10)
        .background(Color.black.opacity(0.5))
        .cornerRadius(20, antialiased: true)
        .padding(.bottom, 10)
    }
}
struct BoButton: View {
    let name: String
    let action: () -> Void
    var body: some View {
        Button(action: {
            self.action()
        }, label: {
            Image(systemName: name)
                .font(.title)
        })
        
    }
}
